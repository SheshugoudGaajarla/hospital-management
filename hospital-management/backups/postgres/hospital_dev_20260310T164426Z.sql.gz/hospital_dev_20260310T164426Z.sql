--
-- PostgreSQL database dump
--

\restrict pHiggFgvrLknCVnN7VVlhsDLtzJDb3iRS0FOiQkJwpxR7dp5AaGdmR7hVcwXIaa

-- Dumped from database version 16.12
-- Dumped by pg_dump version 16.12

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: user_role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.user_role AS ENUM (
    'doctor',
    'admin',
    'laboratory',
    'medical',
    'operations'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    user_id integer,
    module character varying(50) NOT NULL,
    action character varying(50) NOT NULL,
    entity character varying(60) NOT NULL,
    entity_id integer,
    details json,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: consultations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.consultations (
    id integer NOT NULL,
    op_visit_id integer NOT NULL,
    chief_complaint character varying(255) NOT NULL,
    vitals character varying(500),
    diagnosis character varying(255),
    clinical_notes text,
    advice text,
    follow_up_date date,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    prescription_medicines text,
    prescription_dosage text,
    prescription_duration character varying(255),
    prescription_notes text
);


--
-- Name: consultations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.consultations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: consultations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.consultations_id_seq OWNED BY public.consultations.id;


--
-- Name: expenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.expenses (
    id integer NOT NULL,
    category character varying(50) NOT NULL,
    amount numeric(12,2) NOT NULL,
    notes character varying(255),
    expense_date timestamp without time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: expenses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.expenses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: expenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.expenses_id_seq OWNED BY public.expenses.id;


--
-- Name: lab_order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lab_order_items (
    id integer NOT NULL,
    lab_order_id integer NOT NULL,
    test_code character varying(40) NOT NULL,
    test_name character varying(120) NOT NULL,
    department character varying(40) NOT NULL,
    category character varying(80) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: lab_order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.lab_order_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: lab_order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.lab_order_items_id_seq OWNED BY public.lab_order_items.id;


--
-- Name: lab_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lab_orders (
    id integer NOT NULL,
    op_visit_id integer NOT NULL,
    status character varying(30) DEFAULT 'ordered'::character varying NOT NULL,
    result_summary text,
    ordered_at timestamp without time zone DEFAULT now() NOT NULL,
    reported_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: lab_orders_id_seq1; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.lab_orders_id_seq1
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: lab_orders_id_seq1; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.lab_orders_id_seq1 OWNED BY public.lab_orders.id;


--
-- Name: medical_bills; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.medical_bills (
    id integer NOT NULL,
    patient_id integer NOT NULL,
    op_visit_id integer,
    consultation_fee numeric(12,2) NOT NULL,
    lab_fee numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    medicine_fee numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    discount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    tax numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    net_amount numeric(12,2) NOT NULL,
    payment_mode character varying(30) DEFAULT 'cash'::character varying NOT NULL,
    status character varying(30) DEFAULT 'unpaid'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    invoice_no character varying(40) NOT NULL,
    paid_at timestamp without time zone,
    refunded_at timestamp without time zone,
    refund_reason character varying(255)
);


--
-- Name: medical_bills_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.medical_bills_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: medical_bills_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.medical_bills_id_seq OWNED BY public.medical_bills.id;


--
-- Name: op_visits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.op_visits (
    id integer NOT NULL,
    patient_id integer NOT NULL,
    token_no integer NOT NULL,
    doctor_name character varying(120) NOT NULL,
    status character varying(40) DEFAULT 'waiting'::character varying NOT NULL,
    visit_date timestamp without time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    age integer NOT NULL,
    weight_kg numeric(5,2) NOT NULL,
    bp character varying(20) NOT NULL
);


--
-- Name: op_visits_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.op_visits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: op_visits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.op_visits_id_seq OWNED BY public.op_visits.id;


--
-- Name: patients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.patients (
    id integer NOT NULL,
    uhid character varying(30) NOT NULL,
    full_name character varying(120) NOT NULL,
    phone character varying(20),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    village_town character varying(120) NOT NULL
);


--
-- Name: patients_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.patients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: patients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.patients_id_seq OWNED BY public.patients.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    full_name character varying(120) NOT NULL,
    role public.user_role NOT NULL,
    password_hash character varying(255) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: consultations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consultations ALTER COLUMN id SET DEFAULT nextval('public.consultations_id_seq'::regclass);


--
-- Name: expenses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses ALTER COLUMN id SET DEFAULT nextval('public.expenses_id_seq'::regclass);


--
-- Name: lab_order_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lab_order_items ALTER COLUMN id SET DEFAULT nextval('public.lab_order_items_id_seq'::regclass);


--
-- Name: lab_orders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lab_orders ALTER COLUMN id SET DEFAULT nextval('public.lab_orders_id_seq1'::regclass);


--
-- Name: medical_bills id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medical_bills ALTER COLUMN id SET DEFAULT nextval('public.medical_bills_id_seq'::regclass);


--
-- Name: op_visits id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.op_visits ALTER COLUMN id SET DEFAULT nextval('public.op_visits_id_seq'::regclass);


--
-- Name: patients id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patients ALTER COLUMN id SET DEFAULT nextval('public.patients_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
0011_refactor_lab_orders
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, user_id, module, action, entity, entity_id, details, created_at) FROM stdin;
1	1	op	create	op_visit	1	{"token_no": 1, "patient_id": 1}	2026-03-07 16:31:06.522507
2	1	op	status_update	op_visit	1	{"status": "in_consultation"}	2026-03-07 16:37:02.299768
3	2	laboratory	create	lab_order	1	{"op_visit_id": 1, "test_count": 2, "tests": ["CRP", "ESR"]}	2026-03-07 16:40:27.693754
4	1	laboratory	update	lab_order	1	{"status": "collected", "reported_at": null}	2026-03-07 16:41:19.66598
5	1	laboratory	update	lab_order	1	{"status": "processing", "reported_at": null}	2026-03-07 16:41:21.784813
6	1	laboratory	update	lab_order	1	{"status": "completed", "reported_at": "2026-03-07T16:41:34.424200"}	2026-03-07 16:41:34.418745
7	1	op	create	op_visit	2	{"token_no": 1, "patient_id": 2}	2026-03-08 05:21:07.095488
8	1	op	status_update	op_visit	2	{"status": "in_consultation"}	2026-03-08 05:21:25.331912
\.


--
-- Data for Name: consultations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.consultations (id, op_visit_id, chief_complaint, vitals, diagnosis, clinical_notes, advice, follow_up_date, created_at, updated_at, prescription_medicines, prescription_dosage, prescription_duration, prescription_notes) FROM stdin;
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.expenses (id, category, amount, notes, expense_date, created_at) FROM stdin;
\.


--
-- Data for Name: lab_order_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lab_order_items (id, lab_order_id, test_code, test_name, department, category, created_at) FROM stdin;
1	1	CRP	CRP	pediatrics	Inflammation	2026-03-07 16:40:27.693754
2	1	ESR	ESR	pediatrics	Inflammation	2026-03-07 16:40:27.693754
\.


--
-- Data for Name: lab_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lab_orders (id, op_visit_id, status, result_summary, ordered_at, reported_at, created_at) FROM stdin;
1	1	completed	completed	2026-03-07 16:40:27.693754	2026-03-07 16:41:34.4242	2026-03-07 16:40:27.693754
\.


--
-- Data for Name: medical_bills; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.medical_bills (id, patient_id, op_visit_id, consultation_fee, lab_fee, medicine_fee, discount, tax, net_amount, payment_mode, status, created_at, invoice_no, paid_at, refunded_at, refund_reason) FROM stdin;
\.


--
-- Data for Name: op_visits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.op_visits (id, patient_id, token_no, doctor_name, status, visit_date, created_at, age, weight_kg, bp) FROM stdin;
1	1	1	Dr Viday Sagar Reddy	in_consultation	2026-03-07 16:31:06.522507	2026-03-07 16:31:06.522507	39	95.00	120/85
2	2	1	Dr Ch Maduri	in_consultation	2026-03-08 05:21:07.095488	2026-03-08 05:21:07.095488	34	70.00	120/80
\.


--
-- Data for Name: patients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.patients (id, uhid, full_name, phone, created_at, village_town) FROM stdin;
1	UH000001	Shashi	\N	2026-03-07 16:31:06.522507	Yosufnagar
2	UH000002	Sampath	\N	2026-03-08 05:21:07.095488	Ailapur
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, full_name, role, password_hash, created_at) FROM stdin;
1	admin	System Admin	admin	$pbkdf2-sha256$29000$7f2/l7JWqpUyZoxxrtX6vw$JuVc4geIEvrn8jvNCXm8v/dOVTAOsSZpCwW70623bVQ	2026-03-07 16:30:22.945706
2	doctor_ped	Dr Viday Sagar Reddy	doctor	$pbkdf2-sha256$29000$iTHmnPPe2/s/JySEkDLG.A$Qe3l3m7YWjMcb/AOa44YsI8cAfWBAbkQ0ih/t5200xM	2026-03-07 16:39:29.135969
3	doctor_gyn	Dr Ch Maduri	doctor	$pbkdf2-sha256$29000$sBYCwNh7D0HoXUupNeYcww$A2nK.xMMHEIljmrnLzt08NWRTsUqkj74pc/pdEuQlSs	2026-03-07 16:39:29.135969
\.


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 8, true);


--
-- Name: consultations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.consultations_id_seq', 1, false);


--
-- Name: expenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.expenses_id_seq', 1, false);


--
-- Name: lab_order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.lab_order_items_id_seq', 2, true);


--
-- Name: lab_orders_id_seq1; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.lab_orders_id_seq1', 1, true);


--
-- Name: medical_bills_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.medical_bills_id_seq', 1, false);


--
-- Name: op_visits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.op_visits_id_seq', 2, true);


--
-- Name: patients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.patients_id_seq', 2, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 3, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: consultations consultations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consultations
    ADD CONSTRAINT consultations_pkey PRIMARY KEY (id);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: lab_order_items lab_order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lab_order_items
    ADD CONSTRAINT lab_order_items_pkey PRIMARY KEY (id);


--
-- Name: lab_orders lab_orders_pkey1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lab_orders
    ADD CONSTRAINT lab_orders_pkey1 PRIMARY KEY (id);


--
-- Name: medical_bills medical_bills_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medical_bills
    ADD CONSTRAINT medical_bills_pkey PRIMARY KEY (id);


--
-- Name: op_visits op_visits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.op_visits
    ADD CONSTRAINT op_visits_pkey PRIMARY KEY (id);


--
-- Name: patients patients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_pkey PRIMARY KEY (id);


--
-- Name: patients patients_uhid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_uhid_key UNIQUE (uhid);


--
-- Name: consultations uq_consultations_op_visit_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consultations
    ADD CONSTRAINT uq_consultations_op_visit_id UNIQUE (op_visit_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_audit_logs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_logs_created_at ON public.audit_logs USING btree (created_at);


--
-- Name: ix_consultations_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_consultations_created_at ON public.consultations USING btree (created_at);


--
-- Name: ix_expenses_expense_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_expenses_expense_date ON public.expenses USING btree (expense_date);


--
-- Name: ix_lab_order_items_lab_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_lab_order_items_lab_order_id ON public.lab_order_items USING btree (lab_order_id);


--
-- Name: ix_lab_orders_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_lab_orders_created_at ON public.lab_orders USING btree (created_at);


--
-- Name: ix_lab_orders_op_visit_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_lab_orders_op_visit_id ON public.lab_orders USING btree (op_visit_id);


--
-- Name: ix_medical_bills_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_medical_bills_created_at ON public.medical_bills USING btree (created_at);


--
-- Name: ix_medical_bills_invoice_no; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_medical_bills_invoice_no ON public.medical_bills USING btree (invoice_no);


--
-- Name: ix_op_visits_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_op_visits_created_at ON public.op_visits USING btree (created_at);


--
-- Name: ix_patients_uhid; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_patients_uhid ON public.patients USING btree (uhid);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: consultations consultations_op_visit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consultations
    ADD CONSTRAINT consultations_op_visit_id_fkey FOREIGN KEY (op_visit_id) REFERENCES public.op_visits(id) ON DELETE CASCADE;


--
-- Name: lab_order_items lab_order_items_lab_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lab_order_items
    ADD CONSTRAINT lab_order_items_lab_order_id_fkey FOREIGN KEY (lab_order_id) REFERENCES public.lab_orders(id) ON DELETE CASCADE;


--
-- Name: lab_orders lab_orders_op_visit_id_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lab_orders
    ADD CONSTRAINT lab_orders_op_visit_id_fkey1 FOREIGN KEY (op_visit_id) REFERENCES public.op_visits(id) ON DELETE CASCADE;


--
-- Name: medical_bills medical_bills_op_visit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medical_bills
    ADD CONSTRAINT medical_bills_op_visit_id_fkey FOREIGN KEY (op_visit_id) REFERENCES public.op_visits(id) ON DELETE SET NULL;


--
-- Name: medical_bills medical_bills_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medical_bills
    ADD CONSTRAINT medical_bills_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- Name: op_visits op_visits_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.op_visits
    ADD CONSTRAINT op_visits_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict pHiggFgvrLknCVnN7VVlhsDLtzJDb3iRS0FOiQkJwpxR7dp5AaGdmR7hVcwXIaa

