--
-- PostgreSQL database dump
--

\restrict mR4AphcedCrgVJP1Zz95csT8ue6NJEguTIKn9iMc9ZE7D3cETdTAdrfWfSgagCe

-- Dumped from database version 16.12
-- Dumped by pg_dump version 16.12

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: user_role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.user_role AS ENUM (
    'admin',
    'reception',
    'doctor',
    'billing'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    user_id integer,
    module character varying(50) NOT NULL,
    action character varying(50) NOT NULL,
    entity character varying(60) NOT NULL,
    entity_id integer,
    details json,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: expenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.expenses (
    id integer NOT NULL,
    category character varying(50) NOT NULL,
    amount numeric(12,2) NOT NULL,
    notes character varying(255),
    expense_date timestamp without time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: expenses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.expenses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: expenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.expenses_id_seq OWNED BY public.expenses.id;


--
-- Name: medical_bills; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.medical_bills (
    id integer NOT NULL,
    patient_id integer NOT NULL,
    op_visit_id integer,
    consultation_fee numeric(12,2) NOT NULL,
    lab_fee numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    medicine_fee numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    discount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    tax numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    net_amount numeric(12,2) NOT NULL,
    payment_mode character varying(30) DEFAULT 'cash'::character varying NOT NULL,
    status character varying(30) DEFAULT 'unpaid'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    invoice_no character varying(40) NOT NULL,
    paid_at timestamp without time zone,
    refunded_at timestamp without time zone,
    refund_reason character varying(255)
);


--
-- Name: medical_bills_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.medical_bills_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: medical_bills_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.medical_bills_id_seq OWNED BY public.medical_bills.id;


--
-- Name: op_visits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.op_visits (
    id integer NOT NULL,
    patient_id integer NOT NULL,
    token_no integer NOT NULL,
    doctor_name character varying(120) NOT NULL,
    status character varying(40) DEFAULT 'waiting'::character varying NOT NULL,
    visit_date timestamp without time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: op_visits_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.op_visits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: op_visits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.op_visits_id_seq OWNED BY public.op_visits.id;


--
-- Name: patients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.patients (
    id integer NOT NULL,
    uhid character varying(30) NOT NULL,
    full_name character varying(120) NOT NULL,
    phone character varying(20) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: patients_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.patients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: patients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.patients_id_seq OWNED BY public.patients.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    full_name character varying(120) NOT NULL,
    role public.user_role NOT NULL,
    password_hash character varying(255) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: expenses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses ALTER COLUMN id SET DEFAULT nextval('public.expenses_id_seq'::regclass);


--
-- Name: medical_bills id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medical_bills ALTER COLUMN id SET DEFAULT nextval('public.medical_bills_id_seq'::regclass);


--
-- Name: op_visits id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.op_visits ALTER COLUMN id SET DEFAULT nextval('public.op_visits_id_seq'::regclass);


--
-- Name: patients id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patients ALTER COLUMN id SET DEFAULT nextval('public.patients_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
0005_add_invoice_fields_to_bills
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, user_id, module, action, entity, entity_id, details, created_at) FROM stdin;
1	1	op	create	op_visit	2	{"token_no": 2, "patient_id": 2}	2026-03-01 17:44:19.926592
2	1	op	status_update	op_visit	2	{"status": "in_consultation"}	2026-03-01 17:44:22.625896
3	1	op	status_update	op_visit	1	{"status": "in_consultation"}	2026-03-01 17:44:25.195831
4	1	finance	create	expense	2	{"amount": 450.0, "category": "staff"}	2026-03-01 17:44:48.597259
5	1	billing	create	medical_bill	2	{"patient_id": 1, "net_amount": 500.0}	2026-03-01 17:45:08.067346
6	1	op	status_update	op_visit	2	{"status": "completed"}	2026-03-01 17:54:45.521562
7	1	op	status_update	op_visit	1	{"status": "completed"}	2026-03-01 17:54:46.862032
8	1	billing	create	medical_bill	3	{"patient_id": 2, "net_amount": 500.0}	2026-03-01 17:54:54.638115
9	1	op	create	op_visit	3	{"token_no": 1, "patient_id": 3}	2026-03-02 04:50:30.162866
10	1	op	status_update	op_visit	3	{"status": "in_consultation"}	2026-03-02 04:50:34.512869
11	1	op	status_update	op_visit	3	{"status": "completed"}	2026-03-02 04:51:59.838394
12	1	billing	create	medical_bill	4	{"invoice_no": "INV-20260302-0001", "patient_id": 3, "net_amount": 500.0, "status": "paid"}	2026-03-02 04:53:56.319158
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.expenses (id, category, amount, notes, expense_date, created_at) FROM stdin;
1	supplies	100.00	\N	2026-03-01 17:26:48.797446	2026-03-01 17:26:48.797446
2	staff	450.00	\N	2026-03-01 17:44:48.597259	2026-03-01 17:44:48.597259
\.


--
-- Data for Name: medical_bills; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.medical_bills (id, patient_id, op_visit_id, consultation_fee, lab_fee, medicine_fee, discount, tax, net_amount, payment_mode, status, created_at, invoice_no, paid_at, refunded_at, refund_reason) FROM stdin;
1	1	1	500.00	0.00	0.00	0.00	0.00	500.00	cash	paid	2026-03-01 17:26:39.334697	INV-20260301-0001	\N	\N	\N
2	1	1	500.00	0.00	0.00	0.00	0.00	500.00	card	paid	2026-03-01 17:45:08.067346	INV-20260301-0002	\N	\N	\N
3	2	2	500.00	0.00	0.00	0.00	0.00	500.00	cash	paid	2026-03-01 17:54:54.638115	INV-20260301-0003	\N	\N	\N
4	3	3	500.00	0.00	0.00	0.00	0.00	500.00	cash	paid	2026-03-02 04:53:56.319158	INV-20260302-0001	2026-03-02 04:53:56.328835	\N	\N
\.


--
-- Data for Name: op_visits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.op_visits (id, patient_id, token_no, doctor_name, status, visit_date, created_at) FROM stdin;
2	2	2	Dr. Reddy	completed	2026-03-01 17:44:19.926592	2026-03-01 17:44:19.926592
1	1	1	Dr. Mehta	completed	2026-03-01 17:26:27.880709	2026-03-01 17:26:27.880709
3	3	1	Dr. Iqbal	completed	2026-03-02 04:50:30.162866	2026-03-02 04:50:30.162866
\.


--
-- Data for Name: patients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.patients (id, uhid, full_name, phone, created_at) FROM stdin;
1	UH20260301172627883	shashi	9560901505	2026-03-01 17:26:27.880709
2	UH20260301174419931	sheshugoud	6302549671	2026-03-01 17:44:19.926592
3	UH20260302045030166	Bharath	78909877	2026-03-02 04:50:30.162866
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, full_name, role, password_hash, created_at) FROM stdin;
1	admin	System Admin	admin	$pbkdf2-sha256$29000$nNM6B.BcyznHGENIqZWS8g$iRjMtZpPT/.hOTmnv0bZCPO2iJVQ1LLtGrSaOYpmVak	2026-03-01 16:20:28.28446
\.


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 12, true);


--
-- Name: expenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.expenses_id_seq', 2, true);


--
-- Name: medical_bills_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.medical_bills_id_seq', 4, true);


--
-- Name: op_visits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.op_visits_id_seq', 3, true);


--
-- Name: patients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.patients_id_seq', 3, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: medical_bills medical_bills_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medical_bills
    ADD CONSTRAINT medical_bills_pkey PRIMARY KEY (id);


--
-- Name: op_visits op_visits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.op_visits
    ADD CONSTRAINT op_visits_pkey PRIMARY KEY (id);


--
-- Name: patients patients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_pkey PRIMARY KEY (id);


--
-- Name: patients patients_uhid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_uhid_key UNIQUE (uhid);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_audit_logs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_logs_created_at ON public.audit_logs USING btree (created_at);


--
-- Name: ix_expenses_expense_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_expenses_expense_date ON public.expenses USING btree (expense_date);


--
-- Name: ix_medical_bills_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_medical_bills_created_at ON public.medical_bills USING btree (created_at);


--
-- Name: ix_medical_bills_invoice_no; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_medical_bills_invoice_no ON public.medical_bills USING btree (invoice_no);


--
-- Name: ix_op_visits_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_op_visits_created_at ON public.op_visits USING btree (created_at);


--
-- Name: ix_patients_uhid; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_patients_uhid ON public.patients USING btree (uhid);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: medical_bills medical_bills_op_visit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medical_bills
    ADD CONSTRAINT medical_bills_op_visit_id_fkey FOREIGN KEY (op_visit_id) REFERENCES public.op_visits(id) ON DELETE SET NULL;


--
-- Name: medical_bills medical_bills_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medical_bills
    ADD CONSTRAINT medical_bills_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- Name: op_visits op_visits_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.op_visits
    ADD CONSTRAINT op_visits_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict mR4AphcedCrgVJP1Zz95csT8ue6NJEguTIKn9iMc9ZE7D3cETdTAdrfWfSgagCe

